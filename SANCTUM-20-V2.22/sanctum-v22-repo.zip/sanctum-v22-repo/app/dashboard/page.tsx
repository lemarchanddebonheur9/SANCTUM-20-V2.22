export default function DashboardPage() { return <main className="p-8">Dashboard SANCTUM</main> }
